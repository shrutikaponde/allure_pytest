/**
 * @license Angular v5.1.0
 * (c) 2010-2017 Google, Inc. https://angular.io/
 * License: MIT
 */ 
 export * from './animations/animations'
